# Subway Run — pacote atualizado

## Arquivo principal do site
Abra/publica `index.html`. Ele carrega `style.css`, `app.js` e `database.js`. Não publique o HTML antigo da pasta `arquivo_legado` como página principal: ele é uma versão anterior e usa outra implementação de conta/ranking.

## Correções incluídas
- O ranking pessoal NOCOIN registra corridas mesmo sem uma conta criada, salvando os resultados no aparelho.
- Ao criar a primeira conta neste aparelho, o jogo migra o ranking pessoal antigo para essa conta.
- O botão de limpar ranking funciona tanto com conta quanto sem conta.
- O ranking global usa `/api/leaderboard` quando o backend está disponível; quando não está configurado ou ainda não tem resultados, mostra os recordes locais conhecidos neste aparelho e identifica que são locais.
- Ordenação do ranking pessoal desempata pelo número de pontos.

## Para o ranking global funcionar entre todos os jogadores
O ranking global de vários jogadores precisa de um backend publicado. `server.js` é um Cloudflare Worker e exige um banco D1 ligado como binding `DB`.

1. Crie um banco D1 no Cloudflare.
2. Execute no banco os comandos SQL definidos em `database.js` (a constante `schema`, um comando por vez).
3. No Worker, configure o binding D1 com o nome exato `DB`.
4. Publique `server.js` como Worker e configure o roteamento `/api/*` para ele no mesmo domínio do site.
5. A integração de identidade e os cabeçalhos `x-websim-*` foram desenhados para o ambiente Websim. Fora do Websim, o site continuará funcionando localmente, mas o ranking global compartilhado precisa de uma autenticação/backend compatível; não é possível habilitar ranking global real apenas com arquivos estáticos.

## Teste rápido
- Abra o site pelo servidor/hospedagem (não apenas como `file://`, pois módulos JavaScript e APIs podem ser bloqueados por alguns navegadores).
- Faça uma corrida com pelo menos 1 segundo sem coletar moedas.
- Abra **RECORDES → PESSOAL**: o resultado deve aparecer mesmo sem conta.
- Abra **RECORDES → GLOBAL**: se a API estiver conectada, aparecerão resultados do servidor; caso contrário, a tela indica que os dados são locais.

## Observação importante
Não há como garantir que o ranking global compartilhado funcione no site publicado sem acesso à configuração real da hospedagem, banco D1 e autenticação. O código do jogo e o fallback local estão preparados, mas esses serviços externos precisam ser configurados no ambiente onde o site será hospedado.

---

## Sistema de contas online (novo)

**Como funciona**
- Na tela inicial, sem conta logada, aparece o botão **ENTRAR / CRIAR CONTA**.
- Cadastro: usuário (3–14 caracteres, único sem diferenciar maiúsculas) + senha (6–72 caracteres) + avatar/banner.
- A senha é guardada no servidor com PBKDF2-SHA-256 e sal individual; o aparelho guarda só um token de sessão (30 dias) e os dados públicos do perfil.
- Após 5 senhas erradas seguidas a conta fica bloqueada por 10 minutos. Trocar a senha encerra as sessões nos outros aparelhos. Banir um jogador no painel também derruba as sessões dele.
- O recorde NOCOIN de contas online é enviado ao servidor ao fim de cada corrida e aparece no ranking global com avatar e banner.
- **Sem backend** (hospedagem só de arquivos estáticos) o jogo continua criando contas locais, como antes. Contas locais antigas são migradas automaticamente para o servidor no primeiro login com internet, se o nome ainda estiver livre.

**Para ativar (Cloudflare Worker + D1)**
1. Rode de novo o SQL da constante `schema` em `server.js`, um comando por vez. Os comandos são `IF NOT EXISTS`, então é seguro em bancos que já existem; as novas tabelas são `accounts` e `sessions`.
2. Publique o novo `server.js` com o binding D1 `DB` e a rota `/api/*` no mesmo domínio do site.
3. Não depende mais do Websim. Os cabeçalhos `x-websim-*` continuam aceitos só como reserva (painel do dono).

**Endpoints**
`POST /api/auth/register` · `POST /api/auth/login` · `GET /api/auth/me` · `PUT /api/auth/profile` (avatar, banner, troca de senha) · `POST /api/auth/logout`.
Autenticação por `Authorization: Bearer <token>`.

**Limitações conhecidas**
- Não há recuperação de senha nem e-mail (o jogo não coleta e-mail). Quem esquecer a senha perde a conta online.
- O nome de usuário não pode ser alterado depois de criado.

---

## Animações e trem Maria Fumaça (novo)

- **Carrinho (tecla S / deslizar para baixo):** refeito como carrinho de futebol. O personagem entra rápido, desliza deitado para trás com uma perna esticada à frente e a outra levantada, braços para trás, e levanta suavemente no fim. A poeira esguicha à frente dos pés e deixa rastro atrás. A câmera vira de lado durante o carrinho. Continua passando por baixo das barras.
- **Corrida em cima do trem:** corrigido. O jogo tratava a altura do trem como altura de pulo (pernas abertas, parado). Agora o personagem corre normalmente no teto e só usa a pose de pulo quando está realmente no ar.
- **Maria Fumaça:** de tempos em tempos um trem a vapor vem de frente numa pista. Antes aparece um triângulo amarelo piscando na pista e toca um apito. Tem caldeira redonda com farol, chaminé soltando fumaça, vapor nos cilindros, rodas vermelhas, cabine e tenda com carvão. Não dá para passar por cima: é preciso trocar de pista (bater termina a corrida; a prancha ainda absorve a batida). Só sai com a pista livre, sem atravessar outros trens.
  - Ligado em todos os mapas, exceto lua e cyber. Para forçar por mapa, use `steam:true` ou `steam:false` no objeto do mapa em `MAPS`.
  - Ajustes em `app.js`: velocidade `v:560` e tamanho `len:820` (função `step`); frequência em `mtNextAt = dist + rnd(7000, 13000)`.
