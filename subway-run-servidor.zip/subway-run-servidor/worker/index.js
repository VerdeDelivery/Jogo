const SESSION_MS = 30 * 24 * 3600 * 1000;
const NAME_RE = /^[\p{L}\p{N}_ .-]{3,14}$/u;
const enc = new TextEncoder();
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const randomToken = (n = 32) => b64(crypto.getRandomValues(new Uint8Array(n)));
const sha256 = async (txt) => b64(await crypto.subtle.digest("SHA-256", enc.encode(txt)));
// PBKDF2 (100000 iterações é o máximo permitido no Cloudflare Workers)
async function hashPassword(pw, salt) {
  const key = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
  return b64(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: enc.encode(salt), iterations: 100000 }, key, 256));
}
const safeEq = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; };
const cleanAvatar = (v) => /^(\d{1,3}|c_[\w.:-]{1,60})$/.test(String(v ?? "0")) ? String(v ?? "0") : "0";
const cleanBanner = (v) => /^[\w.:-]{0,60}$/.test(String(v ?? "")) ? String(v ?? "") : "";
const publicAccount = (a) => ({ uid: a.id, name: a.username, avatar: a.avatar, banner: a.banner });
async function newSession(env, userId, now) {
  const token = randomToken();
  await env.DB.prepare("INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)").bind(await sha256(token), userId, now, now + SESSION_MS).run();
  return token;
}

const core = {
  async fetch(request, env) {
    const url = new URL(request.url);
    const now = Date.now();
    const json = (data, status = 200) => Response.json(data, { status });
    const bearer = (request.headers.get("authorization") || "").replace(/^Bearer\s+/i, "").trim();
    // Sessão do próprio jogo (Authorization: Bearer <token>)
    let session = null;
    if (bearer) {
      session = await env.DB.prepare("SELECT a.id, a.username, a.avatar, a.banner FROM sessions s JOIN accounts a ON a.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?").bind(await sha256(bearer), now).first();
    }
    const userId = session ? session.id : null, username = session ? session.username : "Jogador";
    // Painel de administração: envie o cabeçalho x-admin-token igual ao segredo ADMIN_TOKEN do servidor
    const adminTok = request.headers.get("x-admin-token") || "";
    const owner = !!env.ADMIN_TOKEN && adminTok.length > 0 && safeEq(adminTok, String(env.ADMIN_TOKEN));
    const ensurePlayer = async () => {
      if (!userId) return { error: json({ error:"Entre na sua conta para sincronizar o progresso." }, 401) };
      const row = await env.DB.prepare("SELECT banned FROM game_users WHERE user_id = ?").bind(userId).first();
      if (row?.banned) return { error: json({ error:"Esta conta foi bloqueada neste jogo." }, 403) };
      return { userId, username };
    };
    const readBody = async () => { try { return await request.json(); } catch { return null; } };

    try {
      if (request.method === "POST" && url.pathname === "/api/auth/register") {
        const b = await readBody(); if (!b) return json({ error:"JSON inválido." }, 400);
        const name = String(b.username || "").trim().replace(/\s+/g, " "), pw = String(b.password || "");
        if (!NAME_RE.test(name)) return json({ error:"Nome de usuário: de 3 a 14 caracteres (letras, números, espaço, _ . -)." }, 400);
        if (pw.length < 6 || pw.length > 72) return json({ error:"A senha precisa ter entre 6 e 72 caracteres." }, 400);
        const lc = name.toLowerCase();
        if (await env.DB.prepare("SELECT 1 AS x FROM accounts WHERE username_lc = ?").bind(lc).first()) return json({ error:"Esse nome de usuário já está em uso." }, 409);
        const id = "u_" + randomToken(12), salt = randomToken(16), hash = await hashPassword(pw, salt);
        const avatar = cleanAvatar(b.avatar), banner = cleanBanner(b.banner);
        try {
          await env.DB.batch([
            env.DB.prepare("INSERT INTO accounts (id, username, username_lc, pw_hash, pw_salt, avatar, banner, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)").bind(id, name, lc, hash, salt, avatar, banner, now),
            env.DB.prepare("INSERT INTO game_users (user_id, username, first_seen, last_seen) VALUES (?, ?, ?, ?)").bind(id, name, now, now),
          ]);
        } catch { return json({ error:"Esse nome de usuário já está em uso." }, 409); }
        return json({ ok:true, token: await newSession(env, id, now), account:{ uid:id, name, avatar, banner } }, 201);
      }

      if (request.method === "POST" && url.pathname === "/api/auth/login") {
        const b = await readBody(); if (!b) return json({ error:"JSON inválido." }, 400);
        const lc = String(b.username || "").trim().replace(/\s+/g, " ").toLowerCase(), pw = String(b.password || "");
        const acc = lc && pw.length <= 72 ? await env.DB.prepare("SELECT * FROM accounts WHERE username_lc = ?").bind(lc).first() : null;
        const bad = json({ error:"Usuário ou senha incorretos." }, 401);
        if (!acc) { await hashPassword(pw.slice(0, 72), "x"); return bad; } // tempo parecido com o de uma conta real
        if (acc.locked_until > now) return json({ error:"Muitas tentativas erradas. Tente de novo em alguns minutos." }, 429);
        if (!safeEq(await hashPassword(pw, acc.pw_salt), acc.pw_hash)) {
          const fails = acc.fail_count + 1;
          await env.DB.prepare("UPDATE accounts SET fail_count = ?, locked_until = ? WHERE id = ?").bind(fails >= 5 ? 0 : fails, fails >= 5 ? now + 10 * 60000 : 0, acc.id).run();
          return bad;
        }
        const g = await env.DB.prepare("SELECT banned FROM game_users WHERE user_id = ?").bind(acc.id).first();
        if (g?.banned) return json({ error:"Esta conta foi bloqueada neste jogo." }, 403);
        await env.DB.prepare("UPDATE accounts SET fail_count = 0, locked_until = 0 WHERE id = ?").bind(acc.id).run();
        return json({ ok:true, token: await newSession(env, acc.id, now), account: publicAccount(acc) });
      }

      if (request.method === "GET" && url.pathname === "/api/auth/me") {
        return session ? json({ ok:true, account: publicAccount({ id:session.id, username:session.username, avatar:session.avatar, banner:session.banner }) }) : json({ error:"Sessão expirada." }, 401);
      }

      if (request.method === "POST" && url.pathname === "/api/auth/logout") {
        if (bearer) await env.DB.prepare("DELETE FROM sessions WHERE token_hash = ?").bind(await sha256(bearer)).run();
        return json({ ok:true });
      }

      if (request.method === "PUT" && url.pathname === "/api/auth/profile") {
        if (!session) return json({ error:"Sessão expirada." }, 401);
        const b = await readBody(); if (!b) return json({ error:"JSON inválido." }, 400);
        const avatar = cleanAvatar(b.avatar ?? session.avatar), banner = cleanBanner(b.banner ?? session.banner);
        if (b.newPassword) {
          const acc = await env.DB.prepare("SELECT pw_hash, pw_salt FROM accounts WHERE id = ?").bind(session.id).first();
          if (!safeEq(await hashPassword(String(b.currentPassword || ""), acc.pw_salt), acc.pw_hash)) return json({ error:"Senha atual incorreta." }, 403);
          const np = String(b.newPassword); if (np.length < 6 || np.length > 72) return json({ error:"A nova senha precisa ter entre 6 e 72 caracteres." }, 400);
          const salt = randomToken(16);
          await env.DB.batch([
            env.DB.prepare("UPDATE accounts SET avatar = ?, banner = ?, pw_salt = ?, pw_hash = ? WHERE id = ?").bind(avatar, banner, salt, await hashPassword(np, salt), session.id),
            env.DB.prepare("DELETE FROM sessions WHERE user_id = ? AND token_hash != ?").bind(session.id, await sha256(bearer)), // derruba outros aparelhos
          ]);
        } else await env.DB.prepare("UPDATE accounts SET avatar = ?, banner = ? WHERE id = ?").bind(avatar, banner, session.id).run();
        return json({ ok:true, account:{ uid:session.id, name:session.username, avatar, banner } });
      }

      if (request.method === "GET" && url.pathname === "/api/leaderboard") {
        const { results } = await env.DB.prepare(
          "SELECT u.username, u.best_score, u.best_no_coin, a.avatar, a.banner, CASE WHEN a.id IS NULL THEN 0 ELSE 1 END AS has_account FROM game_users u LEFT JOIN accounts a ON a.id = u.user_id WHERE u.banned = 0 AND u.best_no_coin > 0 ORDER BY u.best_no_coin DESC, u.best_score DESC LIMIT 50"
        ).all();
        return json(results);
      }

      if (request.method === "POST" && url.pathname === "/api/game/heartbeat") {
        const player = await ensurePlayer();
        if (player.error) return player.error;
        await env.DB.batch([
          env.DB.prepare("INSERT INTO game_users (user_id, username, first_seen, last_seen) VALUES (?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, last_seen = excluded.last_seen")
            .bind(player.userId, player.username, now, now),
          env.DB.prepare("INSERT INTO game_presence (user_id, username, last_seen) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, last_seen = excluded.last_seen")
            .bind(player.userId, player.username, now),
        ]);
        return json({ ok:true, serverTime:now });
      }

      if (request.method === "POST" && url.pathname === "/api/game/score") {
        const player = await ensurePlayer();
        if (player.error) return player.error;
        let body;
        try { body = await request.json(); } catch { return json({ error:"JSON inválido." }, 400); }
        const score = Math.floor(Number(body.score));
        const noCoinSeconds = Math.floor(Number(body.noCoinSeconds));
        const distance = Math.floor(Number(body.distance) || 0);
        const coins = Math.floor(Number(body.coins) || 0);
        if (!Number.isSafeInteger(score) || score < 0 || score > 100000000 || !Number.isSafeInteger(noCoinSeconds) || noCoinSeconds < 0 || noCoinSeconds > 86400 || distance < 0 || distance > 1000000000 || coins < 0 || coins > 1000000) {
          return json({ error:"Resultado inválido." }, 400);
        }
        await env.DB.batch([
          env.DB.prepare("INSERT INTO game_users (user_id, username, first_seen, last_seen, total_runs, best_score, best_no_coin) VALUES (?, ?, ?, ?, 1, ?, ?) ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, last_seen = excluded.last_seen, total_runs = total_runs + 1, best_score = MAX(best_score, excluded.best_score), best_no_coin = MAX(best_no_coin, excluded.best_no_coin)")
            .bind(player.userId, player.username, now, now, score, noCoinSeconds),
          env.DB.prepare("INSERT INTO game_runs (user_id, username, score, no_coin_seconds, distance, coins, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
            .bind(player.userId, player.username, score, noCoinSeconds, distance, coins, now),
        ]);
        return json({ ok:true, updatedAt:now });
      }

      if (request.method === "GET" && url.pathname === "/api/admin/stats") {
        if (!owner) return json({ error:"Acesso de administrador negado." }, 403);
        const cutoff = now - 70000;
        const [users, online, runs, recent] = await Promise.all([
          env.DB.prepare("SELECT COUNT(*) AS total FROM game_users").first(),
          env.DB.prepare("SELECT COUNT(*) AS total FROM game_presence WHERE last_seen >= ?").bind(cutoff).first(),
          env.DB.prepare("SELECT COUNT(*) AS total FROM game_runs").first(),
          env.DB.prepare("SELECT username, score, no_coin_seconds, created_at FROM game_runs ORDER BY created_at DESC LIMIT 8").all(),
        ]);
        const active = await env.DB.prepare("SELECT username, last_seen FROM game_presence WHERE last_seen >= ? ORDER BY last_seen DESC LIMIT 100").bind(cutoff).all();
        return json({ totalUsers:users?.total || 0, onlineNow:online?.total || 0, totalRuns:runs?.total || 0, recentRuns:recent.results || [], onlineUsers:active.results || [], refreshedAt:now });
      }

      if (request.method === "GET" && url.pathname === "/api/admin/users") {
        if (!owner) return json({ error:"Acesso de administrador negado." }, 403);
        const term = (url.searchParams.get("q") || "").trim().slice(0, 60);
        const limit = Math.max(1, Math.min(100, Math.floor(Number(url.searchParams.get("limit")) || 50)));
        const offset = Math.max(0, Math.min(1000000, Math.floor(Number(url.searchParams.get("offset")) || 0)));
        const like = "%" + term + "%";
        const query = "SELECT u.user_id, u.username, u.first_seen, u.last_seen, u.total_runs, u.best_score, u.best_no_coin, u.banned, CASE WHEN p.last_seen >= ? THEN 1 ELSE 0 END AS online FROM game_users u LEFT JOIN game_presence p ON p.user_id = u.user_id WHERE (? = '' OR u.username LIKE ?) ORDER BY u.last_seen DESC LIMIT ? OFFSET ?";
        const { results } = await env.DB.prepare(query).bind(now - 70000, term, like, limit, offset).all();
        return json({ users:results || [], limit, offset });
      }

      if (request.method === "PUT" && url.pathname.startsWith("/api/admin/users/")) {
        if (!owner) return json({ error:"Acesso de administrador negado." }, 403);
        let target;
        try { target = decodeURIComponent(url.pathname.slice("/api/admin/users/".length)); } catch { return json({ error:"Identificador inválido." }, 400); }
        if (!target || target.length > 200) return json({ error:"Identificador inválido." }, 400);
        let body;
        try { body = await request.json(); } catch { return json({ error:"JSON inválido." }, 400); }
        if (typeof body.banned !== "boolean") return json({ error:"Informe banned como boolean." }, 400);
        const result = await env.DB.prepare("UPDATE game_users SET banned = ? WHERE user_id = ?").bind(body.banned ? 1 : 0, target).run();
        if (!result.meta.changes) return json({ error:"Jogador não encontrado." }, 404);
        if (body.banned) await env.DB.batch([env.DB.prepare("DELETE FROM game_presence WHERE user_id = ?").bind(target), env.DB.prepare("DELETE FROM sessions WHERE user_id = ?").bind(target)]);
        return json({ ok:true, userId:target, banned:body.banned });
      }

      return json({ error:"Endpoint não encontrado." }, 404);
    } catch (error) {
      console.error("game api:", error);
      return json({ error:"Falha interna ao acessar o banco do jogo." }, 500);
    }
  },
};

// Permite que o jogo (ou outro jogo seu) hospedado em OUTRO site converse com esta API.
// Sem cookies: a sessão vai no cabeçalho Authorization. Para liberar só alguns sites, defina
// ALLOWED_ORIGINS (ex.: "https://meujogo.com,https://outro.site"); vazio = qualquer site.
export default {
  async fetch(request, env) {
    const origin = request.headers.get("origin") || "";
    const list = String(env.ALLOWED_ORIGINS || "").split(",").map((x) => x.trim().replace(/\/+$/, "")).filter(Boolean);
    const allow = !list.length ? "*" : list.includes(origin) ? origin : "";
    const cors = { "access-control-allow-origin": allow || "null", "access-control-allow-methods": "GET, POST, PUT, DELETE, OPTIONS", "access-control-allow-headers": "authorization, content-type, x-admin-token", "access-control-max-age": "86400", vary: "Origin" };
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    const r = await core.fetch(request, env), h = new Headers(r.headers);
    for (const [k, v] of Object.entries(cors)) h.set(k, v);
    return new Response(r.body, { status: r.status, headers: h });
  },
};
