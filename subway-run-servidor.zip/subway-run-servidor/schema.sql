-- Tabelas do banco do Subway Run (seguro rodar de novo: usa IF NOT EXISTS)
CREATE TABLE IF NOT EXISTS game_users (user_id TEXT PRIMARY KEY, username TEXT NOT NULL, first_seen INTEGER NOT NULL, last_seen INTEGER NOT NULL, total_runs INTEGER NOT NULL DEFAULT 0, best_score INTEGER NOT NULL DEFAULT 0, best_no_coin INTEGER NOT NULL DEFAULT 0, banned INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS game_users_rank ON game_users (banned, best_no_coin DESC, best_score DESC);
CREATE TABLE IF NOT EXISTS game_presence (user_id TEXT PRIMARY KEY, username TEXT NOT NULL, last_seen INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS game_presence_seen ON game_presence (last_seen);
CREATE TABLE IF NOT EXISTS game_runs (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, username TEXT NOT NULL, score INTEGER NOT NULL, no_coin_seconds INTEGER NOT NULL, distance INTEGER NOT NULL, coins INTEGER NOT NULL, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS game_runs_recent ON game_runs (created_at DESC);
CREATE INDEX IF NOT EXISTS game_runs_user ON game_runs (user_id, created_at DESC);
CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, username TEXT NOT NULL, username_lc TEXT NOT NULL UNIQUE, pw_hash TEXT NOT NULL, pw_salt TEXT NOT NULL, avatar TEXT NOT NULL DEFAULT '0', banner TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, fail_count INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS sessions_user ON sessions (user_id);
