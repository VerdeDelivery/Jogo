// Mostra o que está salvo no banco local (contas, ranking, últimas corridas). Nunca mostra senhas.
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
const { DatabaseSync } = await import('node:sqlite');
const file = path.join(path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), 'data', 'subway-run.db');
if (!fs.existsSync(file)) { console.log('Ainda não existe banco. Rode "npm start" e crie uma conta primeiro.'); process.exit(0); }
const db = new DatabaseSync(file, { readOnly: true });
const n = (q) => db.prepare(q).get().n;
const data = (ms) => new Date(ms).toLocaleString('pt-BR');
console.log('\nContas criadas:', n('SELECT COUNT(*) n FROM accounts'), '| Corridas salvas:', n('SELECT COUNT(*) n FROM game_runs'));
console.log('\n== CONTAS ==');
console.table(db.prepare('SELECT username AS usuario, created_at FROM accounts ORDER BY created_at DESC LIMIT 50').all().map(r => ({ usuario: r.usuario, criada_em: data(r.created_at) })));
console.log('== RANKING (maior tempo sem moeda) ==');
console.table(db.prepare('SELECT username AS usuario, best_no_coin AS segundos, best_score AS pontos, total_runs AS corridas, banned AS banido FROM game_users ORDER BY best_no_coin DESC, best_score DESC LIMIT 20').all());
console.log('== ÚLTIMAS CORRIDAS ==');
console.table(db.prepare('SELECT username, score, no_coin_seconds, created_at FROM game_runs ORDER BY created_at DESC LIMIT 10').all().map(r => ({ usuario: r.username, pontos: r.score, segundos_sem_moeda: r.no_coin_seconds, quando: data(r.created_at) })));
