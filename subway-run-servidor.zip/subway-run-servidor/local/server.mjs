// Servidor local do Subway Run: serve o jogo e a API, com banco SQLite em data/subway-run.db.
// Usa o MESMO código (worker/index.js) que roda na Cloudflare. Só precisa do Node.js 22.13 ou mais novo.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const [maj, min] = process.versions.node.split('.').map(Number);
if (maj < 22 || (maj === 22 && min < 13)) {
  console.error('\nEste servidor precisa do Node.js 22.13 ou mais novo (você tem ' + process.versions.node + ').\nBaixe a versão LTS em https://nodejs.org e tente de novo.\n');
  process.exit(1);
}
const { DatabaseSync } = await import('node:sqlite');
const { default: worker } = await import('../worker/index.js');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pub = path.join(root, 'public');
const PORT = Number(process.env.PORT) || 8787, HOST = process.env.HOST || '127.0.0.1';
fs.mkdirSync(path.join(root, 'data'), { recursive: true });
const db = new DatabaseSync(process.env.DB_FILE || path.join(root, 'data', 'subway-run.db'));
db.exec('PRAGMA journal_mode = WAL');
db.exec(fs.readFileSync(path.join(root, 'schema.sql'), 'utf8'));

// Adaptador: faz o SQLite local se comportar como o banco D1 da Cloudflare
const stmt = (sql, args = []) => ({
  bind: (...a) => stmt(sql, a),
  first: async () => db.prepare(sql).get(...args) ?? null,
  all: async () => ({ results: db.prepare(sql).all(...args) }),
  run: async () => ({ meta: { changes: Number(db.prepare(sql).run(...args).changes) } }),
  _run: () => db.prepare(sql).run(...args),
});
const env = {
  ADMIN_TOKEN: process.env.ADMIN_TOKEN || '',
  DB: {
    prepare: (q) => stmt(q),
    batch: async (list) => { db.exec('BEGIN'); try { for (const s of list) s._run(); db.exec('COMMIT'); } catch (e) { db.exec('ROLLBACK'); throw e; } return []; },
  },
};
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.woff2': 'font/woff2' };

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) {
      const chunks = []; for await (const c of req) chunks.push(c);
      const body = ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks);
      const r = await worker.fetch(new Request('http://localhost' + req.url, { method: req.method, headers: req.headers, body }), env);
      res.writeHead(r.status, { ...Object.fromEntries(r.headers), 'content-type': 'application/json', 'cache-control': 'no-store' });
      return res.end(await r.text());
    }
    let file = path.join(pub, decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname));
    if (!file.startsWith(pub + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('Não encontrado'); }
    res.writeHead(200, { 'content-type': types[path.extname(file).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-store' });
    fs.createReadStream(file).pipe(res);
  } catch (e) { console.error(e); res.writeHead(500); res.end('Erro interno'); }
}).listen(PORT, HOST, () => {
  console.log('\n  Subway Run rodando!  Abra no navegador:  http://localhost:' + PORT);
  console.log('  Banco de dados: ' + path.join('data', 'subway-run.db'));
  console.log('  Para parar: Ctrl + C\n');
});
